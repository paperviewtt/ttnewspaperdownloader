<html lang="en">

<head>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4083379420890901"
        crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PaperView Trinidad | All your News Publications Free.</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <style>
        body,
        .container {
            margin: 0;
            font-family: Arial, sans-serif;
            text-align: center;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            max-width: 1028px;
            max-height: 150%;
            padding: 20px;
            border: 15px solid #e4e4e4;
            background-color: #ffffff;
        }

        .logo {
            width: 100px;
            margin: 0 auto;
            display: inline-block;
            vertical-align: middle;
        }

        .welcome-text {
            display: inline-block;
            vertical-align: middle;
            margin-left: 20px;
        }

        .pdf-container {
            width: 100%;
            height: 100%;
            margin-bottom: 10px;
            border: 1px solid #e4e4e4;
            overflow: auto;
        }

        .loader {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            font-size: 1.2em;
            color: #3498db;
        }
    </style>
    <script src="https://mozilla.github.io/pdf.js/build/pdf.js"></script>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v10.0"></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-W4RFYDN669"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'G-W4RFYDN669');
    </script>
</head>

<body>
<?php date_default_timezone_set('America/Caracas');
	    $date = date('Ymd');   
    $formattedDate = date('l, F j, Y');
    $filenameExpress = "download/PPVTT_TrinidadExpressNewsPaper_{$date}.pdf";
    $filenameGuardian = "download/PPVTT_Guardian{$date}.pdf";


    $message = "";
    $filename = "subscribers.json";
    if ($_SERVER["REQUEST_METHOD"] == "POST") { 
        if (isset($_POST["email"])) {
    $email = $_POST["email"];
    $filename = "subscribers.json";

    if (!empty($email)) {
        if (file_exists($filename)) {
            $subscribers = json_decode(file_get_contents($filename), true);
        } else {
            $subscribers = [];
        }
		
		//print_r( $subscribers);
	//	print "inside email";

        if (!in_array($email, $subscribers)) {
            $subscribers[] = $email;
            file_put_contents($filename, json_encode($subscribers));
            $message = "Successfully added to the Daily NewsPaper Mailing List.";
        } else {
            $message = "You are already subscribed to the Daily NewsPaper Mailing List.";
        }
    }
} elseif (isset($_POST["downloadType"])) {
    $date = date('Ymd');
    $downloadType = $_POST["downloadType"];
    $fileToDownload = $downloadType === 'express' ? "pdf/download/PPVTT_TrinidadExpressNewsPaper_{$date}.pdf" : "pdf/download/PPVTT_Guardian{$date}.pdf";
    if (file_exists($fileToDownload)) {
		
	
        header('Content-Description: File Transfer');
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="'.basename($fileToDownload).'"');
      header('Content-Transfer-Encoding: binary'); 
    header('Expires: 0'); 
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0'); 
    header('Pragma: public'); 
        header('Content-Length: ' . filesize($fileToDownload));
        header("Content-Transfer-Encoding: Binary");
		  header('Accept-Ranges: bytes');
		   ob_clean(); 
    flush(); 
        readfile($fileToDownload);
        ob_end_flush(); // End output buffering and send the file content
		//	print $fileToDownload."contes"; die;
        exit;
    }
}
    }

?>

    <div class="container"><a href="/">
		<img src="PaperviewIcon.png" class="logo" alt="logo-paperview-trinidad" /></a>
        <div class="welcome-text">
           <?php if (!empty($message)) { echo "<p style='color:green;'>$message</p>"; } ?>

        </div>

        <!-- Newspaper Selection Menu -->
        <div class="d-inline-block">
            <button class="btn btn-primary me-2" onclick="loadPDF('express')"><i class="bi bi-newspaper"></i> View Express</button>
            <button class="btn btn-primary me-2" onclick="loadPDF('guardian')"><i class="bi bi-newspaper"></i> View Guardian</button>
            <button class="tn btn-secondary btn-sm" onclick="toggleFullScreen('pdf-viewer')"><i class="bi bi-arrows-angle-expand"></i> Full Screen</button>
            <form action="" method="post" id="downloadForm" class="d-inline-block">
                <input type="hidden" name="downloadType" id="downloadType">
                <button type="submit" class="btn btn-secondary btn-sm"><i class="bi bi-download"></i> Download PDF</button>
            </form>
			<button class="tn btn-secondary btn-sm" onclick="navigatePage(-1)"><i class="bi bi-arrow-left"></i> Back</button>
            <button class="tn btn-secondary btn-sm" onclick="navigatePage(1)"><i class="bi bi-arrow-right"></i> Next</button>
        </div>

        <!-- Single PDF Section -->
        <div class="pdf-section mt-3">
            <div class="progress" id="pdf-progress" style="display: none;">
                <div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="pdf-container mt-3" id="pdf-viewer">
                <div class="loader">Loading PDF. Please wait...</div>
            </div>
           
            <button class="tn btn-secondary btn-sm" onclick="toggleFullScreen('pdf-viewer')"><i class="bi bi-arrows-angle-expand"></i> Full Screen</button>
            <form action="" method="post" id="downloadForm" class="d-inline-block">
                <input type="hidden" name="downloadType" id="downloadType">
                <button type="submit" class="btn btn-secondary btn-sm"><i class="bi bi-download"></i> Download PDF</button>
            </form>
			 <button class="tn btn-secondary btn-sm" onclick="navigatePage(-1)"><i class="bi bi-arrow-left"></i> Back</button>
            <button class="tn btn-secondary btn-sm" onclick="navigatePage(1)"><i class="bi bi-arrow-right"></i> Next</button>
        </div>

        <!-- Share Section -->
        <div class="share-section mt-3">
            <div class="fb-share-button" data-href="https://paperviewtt.com" data-layout="button_count"></div>
            <a href="https://twitter.com/share?ref_src=twsrc%5Etfw" class="twitter-share-button" data-text="Check out the latest Trinidad News Papers on PaperViewTT!" data-url="https://paperviewtt.com" data-show-count="false">Tweet</a>
            <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
        </div>

        <!-- Subscription Form -->
        <div class="subscription-section mt-3">
            <h3>Get PDF Daily.</h3>
            <form action="" method="post">
                <div class="input-group mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-envelope-fill"></i> Subscribe</button>
                </div>
            </form>
        </div>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4083379420890901"
            crossorigin="anonymous"></script>
        <!-- paperviewexpress -->
        <ins class="adsbygoogle"
            style="display:block"
            data-ad-client="ca-pub-4083379420890901"
            data-ad-slot="9109953930"
            data-ad-format="auto"
            data-full-width-responsive="true"></ins>
        <script>
            (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.7.2/font/bootstrap-icons.min.css"
        integrity="sha512-1fPmaHba3v4A7PaUsComSM4TBsrrRGs+/fv0vrzafQ+Rw+siILTiJa0NtFfvGeyY5E182SDTaF5PqP+XOHgJag=="
        crossorigin="anonymous"
        referrerpolicy="no-referrer"
    />
    <script>
        (function() {
            var currentPdf, currentPageNum = 1;
            var expressUrl = 'https://paperviewtt.com/pdf/<?php echo $filenameExpress; ?>';
            var guardianUrl = 'https://paperviewtt.com/pdf/<?php echo $filenameGuardian; ?>';

            function renderPage(pdf, pageNum, elementId, quality = 2) {
                pdf.getPage(pageNum).then(function(page) {
                    var scale = quality;
                    var viewport = page.getViewport({ scale: scale });
                    var canvas = document.createElement('canvas');
                    var context = canvas.getContext('2d');
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;
                    var container = document.getElementById(elementId);
                    container.innerHTML = ''; // Clear the container
                    container.appendChild(canvas); // Append the rendered page
                    var renderContext = {
                        canvasContext: context,
                        viewport: viewport
                    };
                    page.render(renderContext).promise.then(function() {
                        // After rendering, append AdSense container
                        var adsenseContainer = document.createElement('ins');
                        adsenseContainer.className = "adsbygoogle";
                        adsenseContainer.style.display = "block";
                        adsenseContainer.dataset.adClient = "ca-pub-4083379420890901";
                        adsenseContainer.dataset.adSlot = "9109953930";
                        adsenseContainer.dataset.adFormat = "auto";
                        adsenseContainer.dataset.fullWidthResponsive = "true";
                        container.appendChild(adsenseContainer);

                        // Initialize the AdSense ad
                        (adsbygoogle = window.adsbygoogle || []).push({});
                    });
                    canvas.style.width = '100%';
                    canvas.style.height = 'auto';
                    var loader = document.querySelector('#' + elementId + ' .loader');
                    if (loader) {
                        loader.style.display = 'none';
                    }
                });
            }

            window.navigatePage = function(direction) {
                currentPageNum += direction;
                renderPage(currentPdf, currentPageNum, 'pdf-viewer');
            }

            window.toggleFullScreen = function(elementId) {
                var elem = document.getElementById(elementId);
                if (!document.fullscreenElement && !document.webkitFullscreenElement && !document.mozFullScreenElement && !document.msFullscreenElement) {
                    if (elem.requestFullscreen) {
                        elem.requestFullscreen();
                    } else if (elem.webkitRequestFullscreen) {
                        elem.webkitRequestFullscreen();
                    } else if (elem.mozRequestFullScreen) {
                        elem.mozRequestFullScreen();
                    } else if (elem.msRequestFullscreen) {
                        elem.msRequestFullscreen();
                    }
                } else {
                    if (document.exitFullscreen) {
                        document.exitFullscreen();
                    } else if (document.webkitExitFullscreen) {
                        document.webkitExitFullscreen();
                    } else if (document.mozCancelFullScreen) {
                        document.mozCancelFullScreen();
                    } else if (document.msExitFullscreen) {
                        document.msExitFullscreen();
                    }
                }
            }

            window.loadPDF = function(type) {
                var url = type === 'express' ? expressUrl : guardianUrl;
                var downloadInput = document.getElementById('downloadType');
                downloadInput.value = type;

                // Display loading message
                var container = document.getElementById('pdf-viewer');
                container.innerHTML = '<div class="loader">Loading PDF. Please wait...</div>';

                // Show the progress bar
                var progressBar = document.getElementById('pdf-progress');
                var progressBarInner = progressBar.querySelector('.progress-bar');
                progressBar.style.display = 'block';
                progressBarInner.style.width = '0%';
                progressBarInner.setAttribute('aria-valuenow', 0);

                var loadingTask = pdfjsLib.getDocument({
                    url: url,
                    onProgress: function(progressData) {
                        var percent = (progressData.loaded / progressData.total) * 100;
                        progressBarInner.style.width = percent + '%';
                        progressBarInner.setAttribute('aria-valuenow', percent);
                        if (percent >= 100) {
                            progressBar.style.display = 'none'; // Hide progress bar when loading is complete
                        }
                    }
                });

                loadingTask.promise.then(function(pdf) {
                    currentPdf = pdf;
                    currentPageNum = 1; // reset to first page
                    renderPage(currentPdf, currentPageNum, 'pdf-viewer');
                });
            }

            // Load default PDF (Express) on page load
            loadPDF('guardian');
        })();
    </script>
</body>

</html>