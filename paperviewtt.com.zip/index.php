<?php date_default_timezone_set('America/Caracas');



$message  = "Received Request at " . time() . "\n";
$message .= "------------------------------------------------------------------------\n";
$message .= "\n";
$message .= json_encode($_REQUEST, JSON_PRETTY_PRINT | JSON_FORCE_OBJECT) . "\n";
$message .= "\n";
$message .= json_encode($_SERVER, JSON_PRETTY_PRINT | JSON_FORCE_OBJECT) . "\n";
$message .= "\n";

$filename = "logger.txt";

file_put_contents("logger.txt", $message, FILE_APPEND);

//echo "OK\n";



	    $date = date('Ymd');   
    $formattedDate = date('l, F j, Y');
    $filenameExpress = "download/PPVTT_TrinidadExpressNewsPaper_{$date}.pdf";
    $filenameGuardian = "download/PPVTT_Guardian{$date}.pdf";
$filenameNewsDay = "download/PPVTT_NewsDay_{$date}.pdf";

    $filenameExpresstu = "download/PPVTT_TrinidadExpressNewsPaper_{$date}.jpg";
    $filenameGuardiantu = "download/PPVTT_Guardian{$date}.jpg";

$filenameNewsDaytu =  "download/PPVTT_NewsDay_{$date}.jpg";

    $message = "";
    $filename = "subscribers.json";
    if ($_SERVER["REQUEST_METHOD"] == "POST") { 
        if (isset($_POST["email"])) {
    $email = $_POST["email"];
    $filename = "subscribers.json";

    if (!empty($email)) {
        if (file_exists($filename)) {
            $subscribers = json_decode(file_get_contents($filename), true);
        } else {
            $subscribers = [];
        }
		
		//print_r( $subscribers);
	//	print "inside email";

        if (!in_array($email, $subscribers)) {
            $subscribers[] = $email;
            file_put_contents($filename, json_encode($subscribers));
            $message = "Successfully added to the Daily NewsPaper Mailing List.";
        } else {
            $message = "You are already subscribed to the Daily NewsPaper Mailing List.";
        }
    }
} elseif (isset($_POST["downloadType"])) {
    $date = date('Ymd');
    $downloadType = $_POST["downloadType"];
    $fileToDownload = $downloadType === 'express' ? "pdf/download/PPVTT_TrinidadExpressNewsPaper_{$date}.pdf" : "pdf/download/PPVTT_Guardian{$date}.pdf";
    if (file_exists($fileToDownload)) {
		
	
        header('Content-Description: File Transfer');
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="'.basename($fileToDownload).'"');
      header('Content-Transfer-Encoding: binary'); 
    header('Expires: 0'); 
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0'); 
    header('Pragma: public'); 
        header('Content-Length: ' . filesize($fileToDownload));
        header("Content-Transfer-Encoding: Binary");
		  header('Accept-Ranges: bytes');
		   ob_clean(); 
    flush(); 
        readfile($fileToDownload);
        ob_end_flush(); // End output buffering and send the file content
		//	print $fileToDownload."contes"; die;
        exit;
    }
}
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4083379420890901"
     crossorigin="anonymous"></script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PaperView Free News Paper Publications</title>
    <script>
        // Break out iframe on iOS cause safari expand iframe to fit the content, thus making
        // the lightbox bigger than the browser window.
        // We need to check for MSStream because Microsoft injected the word iPhone in IE11's userAgent therefore we need to exclude it.
        var iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
        if (iOS && top.location!= self.location) {
            top.location = self.location.href;
        }
    </script>
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

    <!-- Custom Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">

    <!-- Plugin CSS -->
    <link rel="stylesheet" href="css/animate.min.css" type="text/css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/creative.css" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
 
<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid"> 
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
        <a href="/">
		<img src="PaperviewIcon.png" class="logo" width="200px" alt="logo-paperview-trinidad" /></a><button id="toggleDarkMode" class="btn btn-default">Toggle Dark Mode</button>
        <div class="welcome-text">
			<?php echo "<p style='color:red;'>Your are Viewing for $date</p>";  ?>
           <?php if (!empty($message)) { echo "<p style='color:green;'>$message</p>"; } ?>

        </div>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            </div>

            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>


    <section id="services">
        <div class="container">
            <div class="row">
            
                <div id='express-trigger' class="col-lg-4 col-md-6 text-center">
                    <div class="service-box">
                        <img class='book-thumb' src='./pdf/<?php echo $filenameExpresstu; ?>' />
                        <h3> TNTEXPRESS</h3>
      
                    </div>
                </div>
				
				          <div id='guardian-trigger' class="col-lg-4 col-md-6 text-center">
                    <div class="service-box">
                        <img class='book-thumb' src='./pdf/<?php echo $filenameGuardiantu; ?>' />
                        <h3>TNTGUARDIAN</h3>
              
                    </div>
                </div>
				      <div id='newsday-trigger' class="col-lg-4 col-md-6 text-center">
                    <div class="service-box">
                        <img class='book-thumb' src='./pdf/<?php echo $filenameNewsDaytu; ?>' />
                        <h3>TNTNEWSDAY</h3>
              
                    </div>
                </div>
         
         
            </div>
			
        </div>    <aside class="bg-dark">
        <div class="container text-center">
       
            <h3>Get PDF Daily.</h3>
            <form action="" method="post">
                <div class="">
                    <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-envelope-fill"></i> Subscribe</button>
                </div>
            </form>
        </div>
		<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4083379420890901"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="autorelaxed"
     data-ad-client="ca-pub-4083379420890901"
     data-ad-slot="6439929696"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
            </div>
        </div>
    </aside>
    </section>

    <section class="no-padding" id="portfolio">
    </section>



    <section id="contact">
    </section>

    <div style='display: none'>
        <div id='express'></div>
        <div id='guardian'></div>
 

    </div>
	<style>
	
		.hidden-FIXME{
			display: none;
		}
		#portfolio {
			display: none;
		}
		header { display: none; }
		#contact { display: none; }
		#about {
			display: none;
		}

		.navbar-header {
			width: 100% !important;
		}
		.navbar-brand {
			padding-right: 0;
			font-size: 14px !important;
		}
		#nav-buy-now {
			color: black;
			float: right;
			font-size: 14px;
			font-weight: 700;
			margin-right: -10px;
		}
		@media (min-width: 768px) {
			#nav-buy-now {
				margin-right: 0px;
			}
		}
		#bs-example-navbar-collapse-1 {
			display: none;
		}

		.wowbook {
			font-family: "Open Sans","Helvetica Neue",Arial,sans-serif;
		}
		.wowbook-page-content {
			padding: 1.5em;
		}
		.wowbook ul {
			padding-left: 1em;
		}
        .book-thumb {
            height: 360px;
            box-shadow: 0 0 3px rgba(0, 0, 0, 0.5)
        }

		#book1-trigger, #book2-trigger, #book3-trigger {
			cursor: pointer;
		}
		#book1-trigger:hover, #book2-trigger:hover, #book3-trigger:hover {
			background: #f8f8f8;
		}

        .wowbook-lightbox > .wowbook-close {
            background: transparent !important;
            border: none !important;
            color: #222 !important;
            font-size: 2.5em;
        }
        .wowbook-lightbox > .wowbook-close:hover {
            background: #444 !important;
            color: white !important;
            border-radius: 3px;
        }


        .lightbox-images1 .wowbook-book-container {
            background: #ffffff; /* Old browsers */
            background: -moz-radial-gradient(center, ellipse cover, #ffffff 0%, #6d6b92 100%); /* FF3.6-15 */
            background: -webkit-radial-gradient(center, ellipse cover, #ffffff 0%,#6d6b92 100%); /* Chrome10-25,Safari5.1-6 */
            background: radial-gradient(ellipse at center, #ffffff 0%,#6d6b92 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
        }
        .lightbox-images1 > .wowbook-close,
        .lightbox-images2 > .wowbook-close {
            color: #ccc !important;
        }
        .lightbox-images2 .wowbook-book-container {
            background: #ffffff; /* Old browsers */
            background: -moz-radial-gradient(center, ellipse cover, #ffffff 0%, #1E2831 100%); /* FF3.6-15 */
            background: -webkit-radial-gradient(center, ellipse cover, #ffffff 0%,#1E2831 100%); /* Chrome10-25,Safari5.1-6 */
            background: radial-gradient(ellipse at center, #ffffff 0%,#1E2831 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
        }



		.lightbox-pdf  .wowbook-book-container {
			background: #e5e5e5 url(./img/bg-lightbox-pdf.png); /* Old browsers */
			background: #e5e5e5 -moz-radial-gradient(center, ellipse cover, #ffffff 20%, #bbbbbb 100%); /* FF3.6-15 */
			background: #e5e5e5 -webkit-radial-gradient(center, ellipse cover, #ffffff 20%,#bbbbbb 100%); /* Chrome10-25,Safari5.1-6 */
			background: #e5e5e5 radial-gradient(ellipse at center, #ffffff 20%,#bbbbbb 100%); /* W3C, IE10+, FF16+, Chrome26+,Opera12+, Safari7+*/
		}


		.lightbox-html  .wowbook-book-container {
			background: url(img/book_html/wood.jpg);
		}
		.lightbox-html .wowbook-toolbar {
			margin-top: 1em; /* FIXME */
			box-sizing: content-box !important;
		}

		.lightbox-html .wowbook-controls {
			border-radius: 6px;
			width: auto;
		}

		.lightbox-html.wowbook-mobile .wowbook-toolbar {
			margin: 0;
		}

		.lightbox-html.wowbook-mobile .wowbook-controls {
			border-radius: 0;
			width: 100%;
		}


/*		.lightbox-html .wowbook-controls {
			border-radius: 6px;
			width: auto;
			background: none;
			color: rgba(60, 20, 20, 0.8);
			text-shadow: 0 1px 0 #fff;
			box-shadow: none;
		}
		.lightbox-html .wowbook-control:hover {
			background: none;
			color: white;
			text-shadow: 0 1px 0 #fff, 0 0px 5px rgba(60, 20, 20, 1);
			text-shadow: 0 1px 0 #fff, 0 0px 3px #fff;
		}
*/
		hr {
			max-width: 450px;
		}
		body.dark-mode {
    background-color: #121212;
    color: #ffffff;
}

body.dark-mode .navbar {
    background-color: #333;
}

body.dark-mode .service-box {
    background-color: #2a2a2a;
}

	
	</style>
<style>
   

        .logo {
            width: 100px;
            margin: 0 auto;
            display: inline-block;
            vertical-align: middle;
        }

        .welcome-text {
            display: inline-block;
            vertical-align: middle;
            margin-left: 20px;
        }

    </style>
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <script>
        imageBook = ["1", "8"][ Math.floor(Math.random()*2)];
        imageBookPath = "./img/magazine_template_0"+imageBook;
        $("#book1-trigger .book-thumb").attr("src", imageBookPath+"/image_000.jpg")
    </script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jquery.fittext.js"></script>
    <script src="js/wow.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/creative.js"></script>

    <link rel="stylesheet" href="./wow_book/wow_book.css" type="text/css" />
	<style>
		.wowbook-right .wowbook-gutter-shadow {
			background-image: url("./img/page_right_background.png");
			background-position: 0 0;
			width: 75px;
		}
		.wowbook-left .wowbook-gutter-shadow {
			background-image: url("./img/page_left_background.png");
			opacity: 0.5;
			width: 60px;
		}
	</style>
    <script type="text/javascript" src="./wow_book/pdf.combined.min.js"></script>
    <script type="text/javascript" src="./wow_book/wow_book.min.js"></script>
    <script type="text/javascript">
        $(function(){

            function fullscreenErrorHandler(){
                if (self!=top) return "The frame is blocking full screen mode. Click on 'remove frame' button above and try to go full screen again."
            }
			
			document.getElementById("toggleDarkMode").addEventListener("click", function() {
    var bodyElement = document.body;
    if (bodyElement.classList.contains("dark-mode")) {
        bodyElement.classList.remove("dark-mode");
    } else {
        bodyElement.classList.add("dark-mode");
    }
});


 

            var express = {
                 height   : 1024
                ,width    : 725*2
                // ,maxWidth : 800
                // ,maxHeight : 400
                ,pageNumbers: false

                ,pdf: './pdf/<?php echo $filenameExpress; ?>'
                ,pdfFind: true

                ,lightbox : "#express-trigger"
                ,lightboxClass : "lightbox-pdf"
                ,centeredWhenClosed : true
                ,hardcovers : true
                ,curl: false
                ,toolbar: "lastLeft, left, right, lastRight, find, toc, zoomin, zoomout, download, flipsound, fullscreen, thumbnails"
                ,thumbnailsPosition : 'bottom'
                ,responsiveHandleWidth : 50
                ,onFullscreenError: fullscreenErrorHandler
            };
			       var guardian = {
                 height   : 1024
                ,width    : 725*2
                // ,maxWidth : 800
                // ,maxHeight : 400
                ,pageNumbers: false

                ,pdf: './pdf/<?php echo $filenameGuardian; ?>'
                ,pdfFind: true

                ,lightbox : "#guardian-trigger"
                ,lightboxClass : "lightbox-pdf"
                ,centeredWhenClosed : true
                ,hardcovers : true
                ,curl: false
                ,toolbar: "lastLeft, left, right, lastRight, find, toc, zoomin, zoomout, download, flipsound, fullscreen, thumbnails"
                ,thumbnailsPosition : 'bottom'
                ,responsiveHandleWidth : 50
                ,onFullscreenError: fullscreenErrorHandler
            };
			
			    var newsday = {
                 height   : 1024
                ,width    : 725*2
                // ,maxWidth : 800
                // ,maxHeight : 400
                ,pageNumbers: false

                ,pdf: './pdf/<?php echo $filenameNewsDay; ?>'
                ,pdfFind: true

                ,lightbox : "#newsday-trigger"
                ,lightboxClass : "lightbox-pdf"
                ,centeredWhenClosed : true
                ,hardcovers : true
                ,curl: false
                ,toolbar: "lastLeft, left, right, lastRight, find, toc, zoomin, zoomout, download, flipsound, fullscreen, thumbnails"
                ,thumbnailsPosition : 'bottom'
                ,responsiveHandleWidth : 50
                ,onFullscreenError: fullscreenErrorHandler
            };
            

            var books = {
                "#guardian" : guardian,
                "#express" : express,
				"#newsday" : newsday
            };
            $("#guardian-trigger, #express-trigger, #newsday-trigger").on("click",function(){
                buildBook( "#"+this.id.replace("-trigger", "") );
            })

            function buildBook( elem ){
                var book=$.wowBook(elem);
                if (!book) {
                    $(elem).wowBook( books[elem] );
                    book=$.wowBook(elem);
                }
                // book.opts.onHideLightbox = function(){
                //     setTimeout( function(){ book.destroy(); }, 1000);
                // }
                book.showLightbox();
            }


        });
    </script>

</body>

</html>
