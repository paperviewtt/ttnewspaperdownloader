<?php
chdir(dirname(__FILE__));
$rdir = str_replace("\\", "/", __DIR__);
require $rdir.'/PHPMailer/src/Exception.php';
require $rdir.'/PHPMailer/src/PHPMailer.php';
require $rdir.'/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set('America/Caracas'); // Set the timezone to GMT-4

$jsonEmailr = json_decode(file_get_contents('../subscribers.json'), true);

$dateStr = $date = date('Ymd');
$filenameGuardian = "download/PPVTT_Guardian{$dateStr}.pdf";
$filenameExpress = "download/PPVTT_TrinidadExpressNewsPaper_{$dateStr}.pdf";
$filenameExpresslo = "download/PPVTT_TrinidadExpressNewsPaper_low_res{$dateStr}.pdf";

exec("ps2pdf -dPDFSETTINGS=/ebook {$filenameExpress} {$filenameExpresslo}");

$googleEmail = 'paperviewtrinidad@gmail.com';
$googlePassword = 'cztnuxigagjvguil';

foreach ($jsonEmailr as $recipient) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->SMTPDebug = 2;  // Enable verbose debug output. Set to 0 for production
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = $googleEmail;
        $mail->Password = $googlePassword;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom($googleEmail, 'PaperViewTT');
        $mail->addAddress($recipient);
		
		

        // Attach the image
        $mail->addAttachment($filenameExpresslo);

        // Content
        $mail->isHTML(true);
        $mail->Subject = "PaperViewTT {$dateStr}";
        $encodedEmail = base64_encode($recipient);
        $mail->Body = '<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Content</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #e0e0e0;
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .button {
            display: inline-block;
            padding: 12px 24px;
            margin: 10px 0;
            color: #ffffff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .button.view {
            background-color: #4CAF50;
        }

        .button.view:hover {
            background-color: #388E3C;
        }

        .button.express {
            background-color: #FFC107;
            color: #333;
        }

        .button.express:hover {
            background-color: #FFB300;
        }

        .button.guardian {
            background-color: #2196F3;
        }

        .button.guardian:hover {
            background-color: #1976D2;
        }

        p {
            font-size: 16px;
            line-height: 1.5;
            color: #333;
        }
    </style>
</head>

<body>
    <div class="container">
        <a href="https://paperviewtt.com?ref='.$encodedEmail.'" class="button view">View Online</a>
        <p>TrinidadNews Papers PDF for '.$date.'.</p>
        <a href="http://paperviewtt.com/pdf/'.$filenameExpress .'" class="button express">Download Express PDF</a>
        <a href="http://paperviewtt.com/pdf/'.$filenameGuardian .'" class="button guardian">Download Guardian PDF</a>
    </div>
</body>

</html>
';

        $mail->send();
        echo 'Message has been sent to ' . $recipient . '<br>';
    } catch (Exception $e) {
        echo "Message could not be sent to $recipient. Mailer Error: {$mail->ErrorInfo}<br>";
    }
}
?>
