<?php

chdir(dirname(__FILE__));
date_default_timezone_set('America/Caracas');

$rdir = str_replace("\\", "/", __DIR__);
$date = date('Ymd');

// Initialize cURL
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => "https://api.replica.pagesuite.com/publication/50f08b01-57fe-41f5-b9c5-4cc38a883fef/editions/list?month=&maxnumber=4",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "accept-encoding: gzip",
        "host: api.replica.pagesuite.com",
        "user-agent: Dart/2.13 (dart:io)"
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    $data = json_decode($response, true);
    usort($data, function($a, $b) {
        return strtotime($b['lastmodified']) - strtotime($a['lastmodified']);
    });
    $zipUrl = $data[0]['andZipUrl'];
}

$targetDir = "zip/" . $date . "gd";
file_put_contents($targetDir . '.zip', file_get_contents($zipUrl));

$zip = new ZipArchive;
if ($zip->open($targetDir . '.zip') === TRUE) {
    $zip->extractTo($targetDir);
    $zip->close();
    echo 'ZIP extracted successfully.';
} else {
    echo 'Failed to extract ZIP.';
}

$filenameGuardian = "download/PPVTT_Guardian{$date}.pdf";
$jsonData = json_decode(file_get_contents($targetDir . '/hashmap.json'), true);
$hashesForPDF = array_filter($jsonData, function($item) {
    return strpos($item['url'], '.pdf') !== false;
});

$pdfUrls = array_map(function($item) {
    return $item['url']; // Assuming 'url' is the key you want
}, $hashesForPDF);
$allImagesString = implode(' ', $pdfUrls);

$shellstring = "pdftk {$allImagesString} cat output {$filenameGuardian}";

print $shellstring;


exec($shellstring);

$downloadpathgd = "download/PPVTT_Guardian{$date}.jpg";
///Convert THMUB for Page
    exec("convert {$filenameGuardian}[0] {$downloadpathgd}");

print " Guardian THMB GEnerated ";

require $rdir . '/PHPMailer/src/Exception.php';
require $rdir . '/PHPMailer/src/PHPMailer.php';
require $rdir . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

$files = "";
$pagecount = 60;
$start = 1;
for ($x = $start; $x <= $pagecount; $x++) {
    $files .= $date . "ex" . sprintf('%03s', $x) . "_w-or9.pdf.0,";
}
$url = "http://trinidadexpress.tto.app.newsmemory.com/eebrowser/ipad/develop.android.219/ajax-request.php?pSetup=trinidadexpress_android_2795&useDB=1&action=multizippedimages&issue={$date}&filenames={$files}&isXcode=1&TAUID=null&MACHINEID=cd1f706c9862fbe4652620da80d735cc";
$zipFile = "zip/".$date . "tt" . ".zip";

//print $url;

$zip_resource = fopen($zipFile, "w");
$ch_start = curl_init();
curl_setopt_array($ch_start, [
    CURLOPT_URL => $url,
    CURLOPT_FAILONERROR => true,
    CURLOPT_HEADER => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_AUTOREFERER => true,
    CURLOPT_BINARYTRANSFER => true,
    CURLOPT_TIMEOUT => 50,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_FILE => $zip_resource,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1'
]);
$page = curl_exec($ch_start);
if (!$page) {
    echo "Error :- " . curl_error($ch_start);
}
curl_close($ch_start);

$zip = new ZipArchive;
$extractPath = "zip/".$date . "tt";
if ($zip->open($zipFile) != "true") {
    echo "Error :- Unable to open the Zip File";
}
$zip->extractTo($extractPath);
print "TTEXPRESS EXTRACTED";
$zip->close();

$processedImages = [];
$directories = glob($extractPath . '/*', GLOB_ONLYDIR);
foreach ($directories as $directory) {
   $pdfPath = $directory . '/graph.jpg';
  $imagePath = $directory . '/pagetext.pdf';
	
	// $pdfPath = $directory . '/pagetext.pdf';
//    $imagePath = $directory . '/graph.jpg';
	
    if (!file_exists($pdfPath) || filesize($pdfPath) === 0 || !file_exists($imagePath) || filesize($imagePath) === 0) {
        continue;
    }
    $outputPdfPath = $directory . '/output.pdf';
    $tempImagePath = 'temp_page.png';
    $overlayImagePath = 'temp_overlay_page.png';
    exec("convert {$pdfPath} {$tempImagePath}");
    exec("convert -density 610x600 -scale 11.5% {$imagePath} temp_pdf_image.png");
    exec("composite -gravity center -geometry -2+10-10 temp_pdf_image.png {$tempImagePath} {$overlayImagePath}");
    exec("convert {$overlayImagePath} {$outputPdfPath}");
	
	//exec("convert {$outputPdfPath} {$outputPdfPath}");
    $processedImages[] = $outputPdfPath;
    unlink($tempImagePath);
    unlink($overlayImagePath);
    unlink('temp_pdf_image.png');
}

$pages = count($processedImages);
$allImagesString = implode(' ', $processedImages);
$filenameExpress = "download/PPVTT_TrinidadExpressNewsPaper_{$date}.pdf";
$shellstring = "pdftk {$allImagesString} cat output {$filenameExpress}";

exec($shellstring);

$downloadpath = "download/PPVTT_TrinidadExpressNewsPaper_{$date}.jpg";
///Convert THMUB for Page
    exec("convert {$filenameExpress}[0] {$downloadpath}");

print "THUB GENERATED FOR EXPRESS";




?>