
<?php

chdir(dirname(__FILE__));
date_default_timezone_set('America/Caracas');

$rdir = str_replace("\\", "/", __DIR__);
$date = date('Ymd');
print "newsday";

function ordinal($number) {
    $ends = ['th','st','nd','rd','th','th','th','th','th','th'];
    if ((($number % 100) >= 11) && (($number % 100) <= 13))
        return $number . 'th';
    else
        return $number . $ends[$number % 10];
}

function GetNewAuthSignup(){
// Step 1: Generate random email and username
$email = substr(md5(rand()), 0, 10) . "@mailinator.com";
$username = explode('@', $email)[0];
	
	// Initialize cURL session
$ch = curl_init();
print "begin";
// Set cURL options for the first URL
curl_setopt($ch, CURLOPT_URL, 'https://ntouch.newsday.co.tt/cart/?add-to-cart=81');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // Return the transfer as a string
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); // Follow redirects
curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt'); // Save cookies to this file
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt'); // Read cookies from this file
$demo_data = 
    [
        "billing_first_name" => "John",
        "billing_last_name" => "Smith",
        "billing_country" => "TT",
        "billing_address_1" => "123 Elm Street",
        "billing_city" => "Port of Spain",
        "billing_state" => "POS",
        "billing_postcode" => "0868",
        "billing_email" => "john.smith@gmail.com",
        "account_username" => "johnsmith",
        "order_comments" => "Please deliver before noon.",
        "woocommerce-process-checkout-nonce" => "d26b113ee8",
        "_wp_http_referer" => "/?wc-ajax=update_order_review"
    ];
// Execute cURL session for the first URL
curl_exec($ch);

// Set cURL options for the second URL
curl_setopt($ch, CURLOPT_URL, 'https://ntouch.newsday.co.tt/?wc-ajax=checkout');

// Execute cURL session for the second URL
$response = curl_exec($ch);

// Randomly select an entry from the demo data
$random_data = $demo_data[array_rand($demo_data)];

var_dump($response);
// Demo data


// Randomly select an entry from the demo data
$random_data = $demo_data[array_rand($demo_data)];
print "no random";
	print_r($random_data);
// Set cURL options
curl_setopt($ch, CURLOPT_URL, "https://ntouch.newsday.co.tt/?wc-ajax=checkout");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');
curl_setopt($ch, CURLOPT_POSTFIELDS, $demo_data);
	// Set user agent to mimic iPhone 14
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1");


// Execute cURL session
$response = curl_exec($ch);
var_dump($response);
// Print the response
print_r($response);
// Step 2: Check for successful signup
if (preg_match('/key=wc_order_/', $response)) {
    echo "Signup successful!\n";

    // Step 3: Save username and password in a JSON file
    $data = [
        'username' => $username,
        'password' => $email // Assuming password is the email for simplicity
    ];
    file_put_contents('credentials.json', json_encode($data));

    // Step 4: Navigate to the main page
    curl_setopt($ch, CURLOPT_URL, "https://ntouch.newsday.co.tt/");
    $mainPageResponse = curl_exec($ch);

    // Step 5: Use PHP's DOMDocument and XPath to find the link
    $dom = new DOMDocument();
    @$dom->loadHTML($mainPageResponse);
    $xpath = new DOMXPath($dom);
    $links = $xpath->query("//a[contains(@href, 'https://newsday.mediafiles.fi/?auth=')]");

    if ($links->length > 0) {
        $link = $links->item(0)->getAttribute('href');

        // Step 6: Navigate to the found link
        curl_setopt($ch, CURLOPT_URL, $link);
        $finalResponse = curl_exec($ch);
        echo "Navigated to the link: $link\n";
    } else {
        echo "No matching link found.\n";
    }
} else {
    echo "Signup failed.\n";
}

curl_close($ch);
	
}




function generate_url_newsday($date) {
	
	$email = "email1@mailinator.como";
	$password = "password";

$authcode = "230826181444_public-OHu1tS7BiNNKkl7Xiwlkjf8Pyj91OexmqzhDeEi5mU8";

    $base_url = "https://secure.mediafiles.fi/newsday/{$authcode}/Newsday-";
    $day_of_week = date('l', $date);
    $month = date('F', $date);
    $day = ordinal(date('j', $date));
    $year = date('Y', $date);

    $reference_date = strtotime("2023-08-26");
    $days_difference = (int)(($date - $reference_date) / (60 * 60 * 24));
    $issue_no = 10932 + $days_difference;

    $url = $base_url . $day_of_week . "-" . $month . "-" . $day . "-" . $year . "-Issue-No-" . $issue_no . "/files/mobile/";
    return $url;
}

														  
function download_pages_newsday() {
    $current_date = time();
    $url = generate_url_newsday($current_date);
    $page_number = 1;
    $downloaded_files = [];
    $max_pages = 50;

    if (!is_dir("pages_newsday")) {
        mkdir("pages_newsday");
    }

    while ($page_number <= $max_pages) {
        $url2 = $url . $page_number . ".jpg";
        $response = @file_get_contents($url2); print $url2;
        if ($response === false) {
           // break;
        }
        $filename = "pages_newsday/page_" . $page_number . ".jpg";
        file_put_contents($filename, $response);
        $downloaded_files[] = $filename;
        $page_number++;
    }

    if (count($downloaded_files) > 0) {
        $output_pdf = "PPVTT_NewsDay_" . 'download/'.date('Ymd', $current_date) . ".pdf";
        $command = "convert " . implode(" ", $downloaded_files) . " " . $output_pdf;
        exec($command);
    }
}

GetNewAuthSignup(); //die;
//download_pages_newsday();

//$downloadpath = "download/PPVTT_NewsDay_".date('Ymd', $current_date).".jpg";
///Convert THMUB for Page
//    exec("convert {$filenameExpress}[0] {$downloadpath}");

//rint "Newsday fished";
														  
	?>